package com.nexgen.mzeefresh;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import java.util.ArrayList;

public class FarmerActivity extends AppCompatActivity {

    DatabaseHelper db;
    EditText etName, etPhone, etLocation;
    ListView lvFarmers;
    ArrayList<String> farmerNames = new ArrayList<>();
    ArrayList<String> farmerPhones = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer);

        db = new DatabaseHelper(this);
        etName = findViewById(R.id.etFarmerName);
        etPhone = findViewById(R.id.etFarmerPhone);
        etLocation = findViewById(R.id.etFarmerLocation);
        lvFarmers = findViewById(R.id.lvFarmers);

        findViewById(R.id.btnAddFarmer).setOnClickListener(v -> {
            String n = etName.getText().toString().trim();
            String p = etPhone.getText().toString().trim();
            String l = etLocation.getText().toString().trim();
            if (n.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Name and phone required", Toast.LENGTH_SHORT).show();
                return;
            }
            db.addFarmer(n, p, l);
            etName.setText(""); etPhone.setText(""); etLocation.setText("");
            loadFarmers();
            Toast.makeText(this, "Farmer added", Toast.LENGTH_SHORT).show();
        });

        // Tap farmer → call (uses CONTACTS-style intent to dial)
        lvFarmers.setOnItemClickListener((parent, view, position, id) -> {
            String phone = farmerPhones.get(position);
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
                    != PackageManager.PERMISSION_GRANTED) {
                // Fallback: open dialer (no permission needed)
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone)));
            }
        });

        loadFarmers();
    }

    private void loadFarmers() {
        farmerNames.clear();
        farmerPhones.clear();
        Cursor c = db.getAllFarmers();
        while (c.moveToNext()) {
            farmerNames.add(c.getString(c.getColumnIndexOrThrow("name"))
                    + "\n" + c.getString(c.getColumnIndexOrThrow("location")));
            farmerPhones.add(c.getString(c.getColumnIndexOrThrow("phone")));
        }
        c.close();
        lvFarmers.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, farmerNames));
    }
}