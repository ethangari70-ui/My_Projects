package com.nexgen.mzeefresh;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import java.util.ArrayList;

public class ReportsActivity extends AppCompatActivity {

    DatabaseHelper db;
    TextView tvStats;
    ListView lvOrders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        db = new DatabaseHelper(this);
        tvStats = findViewById(R.id.tvStats);
        lvOrders = findViewById(R.id.lvOrders);

        findViewById(R.id.btnSync).setOnClickListener(v -> {
            int n = db.markAllSynced();
            Toast.makeText(this, "Synced " + n + " order(s)", Toast.LENGTH_SHORT).show();
            refresh();
        });

        findViewById(R.id.btnNotify).setOnClickListener(v -> sendNotification());

        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();  // ← ensures list refreshes when returning from Proof
    }

    private void refresh() {
        tvStats.setText("Pending orders: " + db.countPendingOrders());

        ArrayList<String> items = new ArrayList<>();
        Cursor c = db.getAllOrders();
        while (c.moveToNext()) {
            items.add(
                    "#" + c.getInt(c.getColumnIndexOrThrow("id")) +
                            " • " + c.getString(c.getColumnIndexOrThrow("produce")) +
                            " (" + c.getString(c.getColumnIndexOrThrow("quantity")) + " kg)\n" +
                            "Farmer: " + c.getString(c.getColumnIndexOrThrow("farmer")) +
                            " | Pickup: " + c.getString(c.getColumnIndexOrThrow("pickup_date")) +
                            " | " + c.getString(c.getColumnIndexOrThrow("status"))
            );
        }
        c.close();
        lvOrders.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, items));
    }

    private void sendNotification() {
        String CHANNEL_ID = "mzeefresh_alerts";
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "MzeeFresh Alerts", NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
        }

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("MzeeFresh")
                .setContentText("New order received from a farmer!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        if (Build.VERSION.SDK_INT >= 33 &&
                ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 300);
            return;
        }
        nm.notify(1, b.build());
    }
}