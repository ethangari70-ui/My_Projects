package com.nexgen.mzeefresh;

import android.content.Intent;
import android.graphics.Bitmap;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class ProofActivity extends AppCompatActivity implements SensorEventListener {

    private static final int CAMERA_REQUEST = 200;
    ImageView ivPhoto;
    TextView tvAccel;
    SignatureView sigView;

    SensorManager sensorManager;
    Sensor accelerometer;
    float maxImpact = 0f;

    // Modern camera launcher
    ActivityResultLauncher<Intent> cameraLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proof);

        ivPhoto = findViewById(R.id.ivPhoto);
        tvAccel = findViewById(R.id.tvAccel);
        sigView = findViewById(R.id.sigView);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // Camera
        cameraLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        // The thumbnail approach is simple and works without file storage
                        Bundle extras = result.getData().getExtras();
                        Bitmap photo = (Bitmap) extras.get("data");
                        if (photo != null) ivPhoto.setImageBitmap(photo);
                    }
                });

        findViewById(R.id.btnTakePhoto).setOnClickListener(v -> {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraLauncher.launch(intent);
        });

        findViewById(R.id.btnClearSig).setOnClickListener(v -> sigView.clear());

        findViewById(R.id.btnConfirmDelivery).setOnClickListener(v -> {
            if (sigView.isEmpty()) {
                Toast.makeText(this, "Please capture client signature", Toast.LENGTH_SHORT).show();
                return;
            }

            DatabaseHelper db = new DatabaseHelper(this);
            int updated = db.markOldestPendingAsDelivered();

            if (updated > 0) {
                Toast.makeText(this,
                        String.format(Locale.US,
                                "Delivery confirmed ✔  Max impact: %.2f m/s²",
                                maxImpact),
                        Toast.LENGTH_LONG).show();
                finish();
            } else {
                Toast.makeText(this, "No pending order found to confirm", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (accelerometer != null)
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            double magnitude = Math.sqrt(x * x + y * y + z * z);
            float impact = (float) Math.abs(magnitude - SensorManager.GRAVITY_EARTH);
            if (impact > maxImpact) {
                maxImpact = impact;
                tvAccel.setText(String.format(Locale.US, "%.2f m/s²", maxImpact));
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) { }
}