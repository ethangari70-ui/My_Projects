package com.nexgen.mzeefresh;

import android.content.Context;
import android.graphics.*;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class SignatureView extends View {

    private Path path;
    private Paint paint;
    private Canvas canvas;
    private Bitmap bitmap;

    public SignatureView(Context c, AttributeSet a) {
        super(c, a);
        paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setAntiAlias(true);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(4f);
        path = new Path();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (bitmap != null) c.drawBitmap(bitmap, 0, 0, null);
        c.drawPath(path, paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                path.moveTo(x, y);
                break;
            case MotionEvent.ACTION_MOVE:
                path.lineTo(x, y);
                if (canvas != null) canvas.drawPath(path, paint);
                break;
            default:
                break;
        }
        invalidate();
        return true;
    }

    public void clear() {
        path.reset();
        if (bitmap != null) {
            bitmap.eraseColor(Color.TRANSPARENT);
        }
        invalidate();
    }

    public boolean isEmpty() {
        return path.isEmpty();
    }
}