package com.nexgen.mzeefresh;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        db = new DatabaseHelper(this);

        findViewById(R.id.btnNewOrder).setOnClickListener(v ->
                startActivity(new Intent(this, NewOrderActivity.class)));
        findViewById(R.id.btnFarmers).setOnClickListener(v ->
                startActivity(new Intent(this, FarmerActivity.class)));
        findViewById(R.id.btnGps).setOnClickListener(v ->
                startActivity(new Intent(this, GpsActivity.class)));
        findViewById(R.id.btnProof).setOnClickListener(v ->
                startActivity(new Intent(this, ProofActivity.class)));
        findViewById(R.id.btnReports).setOnClickListener(v ->
                startActivity(new Intent(this, ReportsActivity.class)));
        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        TextView tv = findViewById(R.id.tvPendingCount);
        tv.setText("Pending orders: " + db.countPendingOrders());
    }
}