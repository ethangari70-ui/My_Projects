package com.nexgen.mzeefresh;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class NewOrderActivity extends AppCompatActivity {

    DatabaseHelper db;
    Spinner spFarmer;
    EditText etProduce, etQuantity, etDate;
    ArrayList<Long> farmerIds = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_order);

        db = new DatabaseHelper(this);
        spFarmer = findViewById(R.id.spFarmer);
        etProduce = findViewById(R.id.etProduce);
        etQuantity = findViewById(R.id.etQuantity);
        etDate = findViewById(R.id.etDate);

        loadFarmerSpinner();

        findViewById(R.id.btnSaveOrder).setOnClickListener(v -> {
            if (farmerIds.isEmpty()) {
                Toast.makeText(this, "Add a farmer first", Toast.LENGTH_SHORT).show();
                return;
            }
            String produce = etProduce.getText().toString().trim();
            String qty = etQuantity.getText().toString().trim();
            String date = etDate.getText().toString().trim();
            if (produce.isEmpty() || qty.isEmpty() || date.isEmpty()) {
                Toast.makeText(this, "All fields required", Toast.LENGTH_SHORT).show();
                return;
            }
            long farmerId = farmerIds.get(spFarmer.getSelectedItemPosition());
            db.addOrder(farmerId, produce, qty, date);
            Toast.makeText(this, "Order saved", Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    private void loadFarmerSpinner() {
        ArrayList<String> names = new ArrayList<>();
        Cursor c = db.getAllFarmers();
        while (c.moveToNext()) {
            farmerIds.add(c.getLong(c.getColumnIndexOrThrow("id")));
            names.add(c.getString(c.getColumnIndexOrThrow("name")));
        }
        c.close();
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, names);
        spFarmer.setAdapter(adapter);
    }
}