package com.nexgen.mzeefresh;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Locale;

public class GpsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final int LOCATION_PERMISSION_REQUEST = 100;

    private FusedLocationProviderClient client;
    private TextView tvLatLng, tvDistance;
    private Location startLocation;
    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gps);

        tvLatLng = findViewById(R.id.tvLatLng);
        tvDistance = findViewById(R.id.tvDistance);
        client = LocationServices.getFusedLocationProviderClient(this);

        // Get map fragment and register callback
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapSnippet);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        Button btnGet = findViewById(R.id.btnGetLocation);
        btnGet.setOnClickListener(v -> fetchLocation(true));

        findViewById(R.id.btnArrived).setOnClickListener(v -> {
            Toast.makeText(this, "Arrived ✔ — proceeding to Proof of Delivery",
                    Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, ProofActivity.class));
        });

        // Request location permission if needed
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST);
        } else {
            fetchLocation(true);
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
    }

    private void fetchLocation(boolean setStart) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        client.getLastLocation().addOnSuccessListener(loc -> {
            if (loc == null) {
                tvLatLng.setText("Location unavailable");
                return;
            }

            // Update text
            tvLatLng.setText(String.format(Locale.US, "Lat: %.5f, Lng: %.5f",
                    loc.getLatitude(), loc.getLongitude()));

            // Update map snippet
            if (mMap != null) {
                LatLng currentLatLng = new LatLng(loc.getLatitude(), loc.getLongitude());
                mMap.clear();
                mMap.addMarker(new MarkerOptions()
                        .position(currentLatLng)
                        .title("Current Location"));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15f));
            }

            // Handle distance logic
            if (setStart) {
                startLocation = loc;
            } else if (startLocation != null) {
                float meters = startLocation.distanceTo(loc);
                tvDistance.setText(String.format(Locale.US, "Distance: %.1f m", meters));
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            fetchLocation(true);
        } else {
            Toast.makeText(this, "Location permission required for GPS tracking",
                    Toast.LENGTH_SHORT).show();
        }
    }
}