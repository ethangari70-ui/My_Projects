package com.nexgen.mzeefresh;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "mzeefresh.db";
    private static final int DB_VERSION = 1;

    // Users table
    public static final String TABLE_USERS = "users";
    // Farmers table
    public static final String TABLE_FARMERS = "farmers";
    // Orders table
    public static final String TABLE_ORDERS = "orders";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT UNIQUE, " +
                "password TEXT, " +
                "role TEXT)");

        // Farmers table
        db.execSQL("CREATE TABLE " + TABLE_FARMERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "name TEXT, " +
                "phone TEXT, " +
                "location TEXT)");

        // Orders table
        db.execSQL("CREATE TABLE " + TABLE_ORDERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "farmer_id INTEGER, " +
                "produce TEXT, " +
                "quantity TEXT, " +
                "pickup_date TEXT, " +
                "status TEXT DEFAULT 'PENDING', " +
                "synced INTEGER DEFAULT 0)");

        // Default users
        db.execSQL("INSERT INTO " + TABLE_USERS + " (username, password, role) VALUES " +
                "('agent', 'agent123', 'AGENT'), " +
                "('dispatch', 'dispatch123', 'DISPATCHER')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FARMERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDERS);
        onCreate(db);
    }

    // ---- Auth ----
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + TABLE_USERS +
                " WHERE username=? AND password=?", new String[]{username, password});
        boolean ok = c.getCount() > 0;
        c.close();
        return ok;
    }

    // ---- Farmers ----
    public long addFarmer(String name, String phone, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("phone", phone);
        cv.put("location", location);
        return db.insert(TABLE_FARMERS, null, cv);
    }

    public Cursor getAllFarmers() {
        return this.getReadableDatabase().rawQuery("SELECT * FROM " + TABLE_FARMERS + " ORDER BY name", null);
    }

    // ---- Orders ----
    public long addOrder(long farmerId, String produce, String quantity, String pickupDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("farmer_id", farmerId);
        cv.put("produce", produce);
        cv.put("quantity", quantity);
        cv.put("pickup_date", pickupDate);
        return db.insert(TABLE_ORDERS, null, cv);
    }

    public Cursor getAllOrders() {
        return this.getReadableDatabase().rawQuery(
                "SELECT o.id, o.produce, o.quantity, o.pickup_date, o.status, f.name AS farmer " +
                        "FROM orders o LEFT JOIN farmers f ON o.farmer_id = f.id ORDER BY o.id DESC", null);
    }

    public int countPendingOrders() {
        Cursor c = this.getReadableDatabase().rawQuery(
                "SELECT COUNT(*) FROM " + TABLE_ORDERS + " WHERE status='PENDING'", null);
        int count = 0;
        if (c.moveToFirst()) count = c.getInt(0);
        c.close();
        return count;
    }

    public int markAllSynced() {
        ContentValues cv = new ContentValues();
        cv.put("synced", 1);
        return this.getWritableDatabase().update(TABLE_ORDERS, cv, "synced=0", null);
    }
    public int markOrderDelivered(int orderId) {
        ContentValues cv = new ContentValues();
        cv.put("status", "DELIVERED");
        cv.put("synced", 0); // mark as not-yet-synced so Reports can sync it
        return this.getWritableDatabase().update(
                TABLE_ORDERS, cv, "id=?", new String[]{String.valueOf(orderId)});
    }

    public int markOldestPendingAsDelivered() {
        // Convenience: mark the most recent PENDING order as DELIVERED
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(
                "SELECT id FROM " + TABLE_ORDERS +
                        " WHERE status='PENDING' ORDER BY id DESC LIMIT 1", null);
        int id = -1;
        if (c.moveToFirst()) id = c.getInt(0);
        c.close();
        if (id == -1) return 0;
        return markOrderDelivered(id);
    }
}