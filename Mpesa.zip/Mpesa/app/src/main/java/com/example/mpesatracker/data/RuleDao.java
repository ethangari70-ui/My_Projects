package com.example.mpesatracker.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface RuleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void upsert(CategoryRule rule);

    @Query("SELECT category FROM category_rules WHERE party = :partyUpper LIMIT 1")
    String find(String partyUpper);
}
