package com.example.mpesatracker.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface TransactionDao {

    /** Types that take money out of your M-Pesa. */
    String OUT = "('SENT','PAYBILL','TILL','WITHDRAW','AIRTIME')";

    /** @return the new row id, or -1 if this M-Pesa code was already saved. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    long insert(TransactionEntity t);

    @Query("SELECT * FROM transactions WHERE timestamp >= :from AND timestamp < :to ORDER BY timestamp DESC")
    List<TransactionEntity> getBetween(long from, long to);

    @Query("UPDATE transactions SET category = :category, categoryLocked = 1 WHERE id = :id")
    void setCategory(long id, String category);

    /** Applies a corrected category to other not-yet-corrected transactions with the same party. */
    @Query("UPDATE transactions SET category = :category WHERE party = :party AND categoryLocked = 0")
    void setCategoryForParty(String party, String category);

    @Query("SELECT COALESCE(SUM(amount), 0) FROM transactions "
            + "WHERE type = 'RECEIVED' AND timestamp >= :from AND timestamp < :to")
    double income(long from, long to);

    /** Spending including fees. Money moved into savings is not counted as spending. */
    @Query("SELECT COALESCE(SUM(amount + fee), 0) FROM transactions "
            + "WHERE type IN " + OUT + " AND category != 'Savings' AND timestamp >= :from AND timestamp < :to")
    double spent(long from, long to);

    @Query("SELECT COALESCE(SUM(fee), 0) FROM transactions "
            + "WHERE type IN " + OUT + " AND timestamp >= :from AND timestamp < :to")
    double fees(long from, long to);

    @Query("SELECT COALESCE(SUM(amount), 0) FROM transactions "
            + "WHERE type IN " + OUT + " AND category = 'Savings' AND timestamp >= :from AND timestamp < :to")
    double movedToSavings(long from, long to);
}
