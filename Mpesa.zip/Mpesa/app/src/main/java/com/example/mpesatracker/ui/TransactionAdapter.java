package com.example.mpesatracker.ui;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mpesatracker.R;
import com.example.mpesatracker.data.TransactionEntity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.Holder> {

    public interface OnItemClick {
        void onClick(TransactionEntity transaction);
    }

    private final List<TransactionEntity> items = new ArrayList<>();
    private final OnItemClick listener;
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("d MMM, h:mm a", Locale.ENGLISH);

    public TransactionAdapter(OnItemClick listener) {
        this.listener = listener;
    }

    public void submit(List<TransactionEntity> list) {
        items.clear();
        items.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        TransactionEntity t = items.get(position);

        h.title.setText(t.party.isEmpty() ? t.type : t.party);
        h.subtitle.setText(t.category + "  \u00B7  " + dateFormat.format(new Date(t.timestamp)));

        String amount = String.format(Locale.ENGLISH, "%,.2f", t.amount);
        if (t.type.equals("RECEIVED")) {
            h.amount.setText("+" + amount);
            h.amount.setTextColor(Color.parseColor("#2E7D32"));
        } else if (isOutflow(t.type)) {
            h.amount.setText("-" + amount);
            h.amount.setTextColor(Color.parseColor("#C62828"));
        } else {
            h.amount.setText(amount);
            h.amount.setTextColor(Color.GRAY);
        }

        h.itemView.setOnClickListener(v -> listener.onClick(t));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private static boolean isOutflow(String type) {
        return type.equals("SENT") || type.equals("PAYBILL") || type.equals("TILL")
                || type.equals("WITHDRAW") || type.equals("AIRTIME");
    }

    static class Holder extends RecyclerView.ViewHolder {
        final TextView title, subtitle, amount;

        Holder(@NonNull View v) {
            super(v);
            title = v.findViewById(R.id.itemTitle);
            subtitle = v.findViewById(R.id.itemSubtitle);
            amount = v.findViewById(R.id.itemAmount);
        }
    }
}
