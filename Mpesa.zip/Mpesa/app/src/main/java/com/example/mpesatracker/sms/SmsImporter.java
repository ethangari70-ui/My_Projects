package com.example.mpesatracker.sms;

import android.content.Context;
import android.database.Cursor;
import android.provider.Telephony;

import com.example.mpesatracker.data.TransactionRepository;

/** Reads every M-Pesa message already in the inbox. Call off the main thread. */
public final class SmsImporter {

    private SmsImporter() { }

    /** @return how many NEW transactions were added. */
    public static int importInbox(Context context) {
        TransactionRepository repo = new TransactionRepository(context);
        int added = 0;

        try (Cursor c = context.getContentResolver().query(
                Telephony.Sms.Inbox.CONTENT_URI,
                new String[]{Telephony.Sms.BODY},
                Telephony.Sms.ADDRESS + " LIKE ?",
                new String[]{"MPESA"},
                Telephony.Sms.DATE + " ASC")) {

            if (c == null) return 0;
            int body = c.getColumnIndexOrThrow(Telephony.Sms.BODY);
            while (c.moveToNext()) {
                if (repo.saveSms(c.getString(body))) added++;
            }
        }
        return added;
    }
}
