package com.example.mpesatracker.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

/** "Whenever the party is X, use category Y". Created when you correct a category. */
@Entity(tableName = "category_rules")
public class CategoryRule {
    @PrimaryKey @NonNull public String party = "";   // stored in UPPER CASE
    public String category;

    public CategoryRule() { }

    @Ignore
    public CategoryRule(@NonNull String party, String category) {
        this.party = party;
        this.category = category;
    }
}
