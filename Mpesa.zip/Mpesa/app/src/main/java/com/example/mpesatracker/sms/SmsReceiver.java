package com.example.mpesatracker.sms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Telephony;
import android.telephony.SmsMessage;

import com.example.mpesatracker.data.TransactionRepository;

import java.util.concurrent.Executors;

/** Saves each new M-Pesa message the moment it arrives. */
public class SmsReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(intent.getAction())) return;

        SmsMessage[] parts = Telephony.Sms.Intents.getMessagesFromIntent(intent);
        if (parts == null || parts.length == 0) return;

        String sender = parts[0].getOriginatingAddress();
        if (sender == null || !sender.equalsIgnoreCase("MPESA")) return;

        // A long message arrives in several parts: join them
        StringBuilder body = new StringBuilder();
        for (SmsMessage part : parts) body.append(part.getMessageBody());

        final Context app = context.getApplicationContext();
        final PendingResult pending = goAsync();   // keeps the receiver alive while we use the database
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                new TransactionRepository(app).saveSms(body.toString());
            } finally {
                pending.finish();
            }
        });
    }
}
