package com.example.mpesatracker.data;

import com.example.mpesatracker.parser.MpesaParser;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Decides a category for a parsed transaction.
 * Order: transaction type -> categories you taught it -> keyword rules -> fallback.
 */
public final class Categorizer {

    /** Looks up a category you corrected earlier. Key is the party name in UPPER CASE. */
    public interface RuleSource {
        String find(String partyUpper);
    }

    public static final String SAVINGS = "Savings";

    public static final String[] CATEGORIES = {
            "Food & Groceries", "Transport", "Utilities", "Airtime & Data", "Rent",
            "Health", "Education", "Entertainment", "Shopping", "Betting",
            SAVINGS, "Income", "Cash Withdrawal", "Transfers", "Uncategorised"
    };

    private static final Map<String, String[]> KEYWORDS = new LinkedHashMap<>();
    static {
        // Savings goes first so e.g. "SACCO" is never mistaken for something else
        KEYWORDS.put(SAVINGS, new String[]{"SHWARI", "KCB M-PESA", "SACCO", "MONEY MARKET", "MMF"});
        KEYWORDS.put("Utilities", new String[]{"KENYA POWER", "KPLC", "WATER", "ZUKU", "STARTIMES",
                "DSTV", "GOTV", "MULTICHOICE", "WANANCHI", "FAIBA"});
        KEYWORDS.put("Airtime & Data", new String[]{"SAFARICOM", "AIRTEL", "TELKOM"});
        KEYWORDS.put("Food & Groceries", new String[]{"NAIVAS", "QUICKMART", "CARREFOUR", "CHANDARANA",
                "SUPERMARKET", "KFC", "JAVA", "ARTCAFFE", "PIZZA", "RESTAURANT", "CAFE",
                "BUTCHERY", "GROCER", "MBOGA", "BAKERY"});
        KEYWORDS.put("Transport", new String[]{"UBER", "BOLT", "LITTLE CAB", "MATATU", "SHELL",
                "RUBIS", "VIVO", "OILIBYA", "PETROL", "FUEL", "SGR", "KENYA RAILWAYS"});
        KEYWORDS.put("Health", new String[]{"PHARMACY", "HOSPITAL", "CLINIC", "CHEMIST", "NHIF", "SHA "});
        KEYWORDS.put("Education", new String[]{"SCHOOL", "UNIVERSITY", "COLLEGE", "HELB", "KUCCPS"});
        KEYWORDS.put("Entertainment", new String[]{"NETFLIX", "SHOWMAX", "SPOTIFY", "CINEMA", "CINEPLEX"});
        KEYWORDS.put("Betting", new String[]{"BETIKA", "SPORTPESA", "ODIBETS", "MOZZART", "1XBET"});
        KEYWORDS.put("Shopping", new String[]{"JUMIA", "KILIMALL", "BOUTIQUE", "FASHION"});
        KEYWORDS.put("Rent", new String[]{"RENT", "LANDLORD"});
    }

    private Categorizer() { }

    public static String categorize(MpesaParser.Transaction t, RuleSource learned) {
        switch (t.type) {
            case RECEIVED: return "Income";
            case AIRTIME:  return "Airtime & Data";
            case WITHDRAW: return "Cash Withdrawal";
            default:       break;
        }

        String party = t.party == null ? "" : t.party.toUpperCase(Locale.ENGLISH).trim();
        if (party.isEmpty()) return "Uncategorised";

        if (learned != null) {
            String category = learned.find(party);
            if (category != null) return category;
        }

        for (Map.Entry<String, String[]> entry : KEYWORDS.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (party.contains(keyword)) return entry.getKey();
            }
        }

        // Money sent to a person with no other clue
        return t.type == MpesaParser.Type.SENT ? "Transfers" : "Uncategorised";
    }
}
