package com.example.mpesatracker.data;

import android.content.Context;

import com.example.mpesatracker.parser.MpesaParser;

/** Single place that turns an SMS into a stored, categorised transaction. Call off the main thread. */
public class TransactionRepository {

    private final TransactionDao dao;
    private final RuleDao rules;

    public TransactionRepository(Context context) {
        AppDatabase db = AppDatabase.get(context);
        this.dao = db.transactionDao();
        this.rules = db.ruleDao();
    }

    /** @return true if a new transaction was stored (false: not M-Pesa, or already saved). */
    public boolean saveSms(String body) {
        MpesaParser.Transaction t = MpesaParser.parse(body);
        if (t == null) return false;

        TransactionEntity e = new TransactionEntity();
        e.code = t.code;
        e.type = t.type.name();
        e.amount = t.amount;
        e.fee = t.fee;
        e.balance = t.balance;
        e.party = t.party == null ? "" : t.party;
        e.account = t.account == null ? "" : t.account;
        e.timestamp = t.timestamp;
        e.raw = t.raw;
        e.category = Categorizer.categorize(t, rules::find);

        return dao.insert(e) != -1;
    }
}
