package com.example.mpesatracker.parser;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Turns one M-Pesa SMS into a Transaction.
 *
 * - Returns null if the text is not a recognisable M-Pesa confirmation.
 * - A message with a valid code and an amount but an unfamiliar layout
 *   comes back as Type.UNKNOWN, so nothing is silently lost.
 *
 * Amounts are doubles (KES, 2 decimals). If rounding ever shows up in your
 * totals, switch to storing cents as long.
 */
public final class MpesaParser {

    public enum Type { RECEIVED, SENT, PAYBILL, TILL, WITHDRAW, AIRTIME, UNKNOWN }

    public static final class Transaction {
        public String code;
        public Type type = Type.UNKNOWN;
        public double amount;
        public double fee;
        public double balance;
        public String party = "";    // person, till, paybill or agent
        public String account = "";  // paybill account number, if any
        public long timestamp;       // epoch millis, 0 if the date could not be read
        public String raw;           // original SMS text

        public boolean isOutflow() {
            return type == Type.SENT || type == Type.PAYBILL || type == Type.TILL
                    || type == Type.WITHDRAW || type == Type.AIRTIME;
        }

        /** What this transaction really cost you: amount plus the M-Pesa fee. */
        public double totalCost() {
            return amount + fee;
        }
    }

    private static final int CI = Pattern.CASE_INSENSITIVE;
    private static final String KSH = "Ksh\\s?([\\d,]+(?:\\.\\d{1,2})?)";

    // Shared parts
    private static final Pattern CODE = Pattern.compile("^([A-Z0-9]{10})\\s+confirmed", CI);
    private static final Pattern ANY_AMOUNT = Pattern.compile(KSH, CI);
    private static final Pattern BALANCE = Pattern.compile("balance\\s+is\\s+" + KSH, CI);
    private static final Pattern FEE = Pattern.compile("Transaction\\s+cost,?\\s+" + KSH, CI);
    private static final Pattern DATE_TIME = Pattern.compile(
            "on\\s+(\\d{1,2}/\\d{1,2}/\\d{2,4})\\s+at\\s+(\\d{1,2}:\\d{2}\\s?[AP]M)", CI);

    // One pattern per transaction type
    private static final Pattern RECEIVED = Pattern.compile(
            "received\\s+" + KSH + "\\s+from\\s+(.+?)\\s+on\\s+\\d", CI);
    private static final Pattern PAYBILL = Pattern.compile(
            KSH + "\\s+sent\\s+to\\s+(.+?)\\s+for\\s+account\\s+(.+?)\\s+on\\s+\\d", CI);
    private static final Pattern SENT = Pattern.compile(
            KSH + "\\s+sent\\s+to\\s+(.+?)\\s+on\\s+\\d", CI);
    private static final Pattern TILL = Pattern.compile(
            KSH + "\\s+paid\\s+to\\s+(.+?)\\.?\\s+on\\s+\\d", CI);
    private static final Pattern WITHDRAW = Pattern.compile(
            "withdraw\\s+" + KSH + "\\s+from\\s+(.+?)\\s+New\\s+M-PESA", CI);
    private static final Pattern AIRTIME = Pattern.compile(
            "bought\\s+" + KSH + "\\s+of\\s+airtime", CI);

    private MpesaParser() { }

    public static Transaction parse(String sms) {
        if (sms == null) return null;

        // Collapse line breaks and double spaces so the patterns stay simple
        String msg = sms.replaceAll("\\s+", " ").trim();

        Matcher codeM = CODE.matcher(msg);
        if (!codeM.find()) return null;

        Transaction t = new Transaction();
        t.code = codeM.group(1).toUpperCase(Locale.ENGLISH);
        t.raw = sms;

        // Order matters: PAYBILL must be tried before SENT, because a paybill
        // message also matches the plain "sent to" pattern.
        Matcher m;
        if ((m = RECEIVED.matcher(msg)).find()) {
            t.type = Type.RECEIVED;
            t.amount = money(m.group(1));
            t.party = cleanParty(m.group(2));
        } else if ((m = PAYBILL.matcher(msg)).find()) {
            t.type = Type.PAYBILL;
            t.amount = money(m.group(1));
            t.party = cleanParty(m.group(2));
            t.account = m.group(3).trim();
        } else if ((m = SENT.matcher(msg)).find()) {
            t.type = Type.SENT;
            t.amount = money(m.group(1));
            t.party = cleanParty(m.group(2));
        } else if ((m = TILL.matcher(msg)).find()) {
            t.type = Type.TILL;
            t.amount = money(m.group(1));
            t.party = cleanParty(m.group(2));
        } else if ((m = WITHDRAW.matcher(msg)).find()) {
            t.type = Type.WITHDRAW;
            t.amount = money(m.group(1));
            t.party = cleanParty(m.group(2));
        } else if ((m = AIRTIME.matcher(msg)).find()) {
            t.type = Type.AIRTIME;
            t.amount = money(m.group(1));
            t.party = "Airtime";
        } else {
            // Unfamiliar layout (Fuliza, reversals, M-Shwari...): keep it as UNKNOWN
            m = ANY_AMOUNT.matcher(msg);
            if (!m.find()) return null;
            t.amount = money(m.group(1));
        }

        m = FEE.matcher(msg);
        if (m.find()) t.fee = money(m.group(1));

        m = BALANCE.matcher(msg);
        if (m.find()) t.balance = money(m.group(1));

        m = DATE_TIME.matcher(msg);
        if (m.find()) t.timestamp = parseTime(m.group(1), m.group(2));

        return t;
    }

    private static double money(String s) {
        return Double.parseDouble(s.replace(",", ""));
    }

    /** Removes a trailing phone number (full or masked like 0712***456). */
    private static String cleanParty(String s) {
        return s.replaceAll("\\s+\\+?[\\d*]{9,}$", "").trim();
    }

    private static long parseTime(String date, String time) {
        // "2:30PM" -> "2:30 PM"
        String t = time.replaceAll("(?i)\\s?([AP]M)", " $1").toUpperCase(Locale.ENGLISH);
        // "yy" also accepts a 4-digit year, so 5/10/26 and 5/10/2026 both work
        SimpleDateFormat f = new SimpleDateFormat("d/M/yy h:mm a", Locale.ENGLISH);
        try {
            return f.parse(date + " " + t).getTime();
        } catch (ParseException e) {
            return 0L;
        }
    }
}
