package com.example.mpesatracker.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** One M-Pesa transaction. The M-Pesa code is unique, so re-importing never creates duplicates. */
@Entity(tableName = "transactions",
        indices = {@Index(value = {"code"}, unique = true), @Index(value = {"timestamp"})})
public class TransactionEntity {
    @PrimaryKey(autoGenerate = true)
    public long id;

    @NonNull public String code = "";
    @NonNull public String type = "UNKNOWN";   // MpesaParser.Type name
    public double amount;
    public double fee;
    public double balance;
    @NonNull public String party = "";
    @NonNull public String account = "";
    public long timestamp;
    @NonNull public String category = "Uncategorised";
    public boolean categoryLocked;             // true once you corrected it by hand
    public String raw;
}
