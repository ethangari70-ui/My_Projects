package com.example.mpesatracker.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mpesatracker.R;
import com.example.mpesatracker.data.AppDatabase;
import com.example.mpesatracker.data.Categorizer;
import com.example.mpesatracker.data.CategoryRule;
import com.example.mpesatracker.data.TransactionDao;
import com.example.mpesatracker.data.TransactionEntity;
import com.example.mpesatracker.sms.SmsImporter;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private AppDatabase db;
    private TransactionAdapter adapter;
    private TextView incomeView, spentView, feesView, savedView, statusView;

    private final ActivityResultLauncher<String[]> permissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                if (Boolean.TRUE.equals(result.get(Manifest.permission.READ_SMS))) {
                    importMessages();
                } else {
                    statusView.setText("SMS permission denied, so the app cannot read your M-Pesa messages.");
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = AppDatabase.get(this);
        incomeView = findViewById(R.id.incomeValue);
        spentView = findViewById(R.id.spentValue);
        feesView = findViewById(R.id.feesValue);
        savedView = findViewById(R.id.savedValue);
        statusView = findViewById(R.id.statusText);

        adapter = new TransactionAdapter(this::pickCategory);
        RecyclerView list = findViewById(R.id.transactionList);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        refresh();

        if (hasSmsPermission()) {
            importMessages();
        } else {
            permissionLauncher.launch(new String[]{Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS});
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (adapter != null) refresh();   // pick up messages that arrived while the app was closed
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void importMessages() {
        statusView.setText("Importing M-Pesa messages...");
        io.execute(() -> {
            int added = SmsImporter.importInbox(getApplicationContext());
            runOnUiThread(() -> {
                statusView.setText(added + " new transactions imported");
                refresh();
            });
        });
    }

    /** Reloads this month's totals and transaction list. */
    private void refresh() {
        Calendar start = Calendar.getInstance();
        start.set(Calendar.DAY_OF_MONTH, 1);
        start.set(Calendar.HOUR_OF_DAY, 0);
        start.set(Calendar.MINUTE, 0);
        start.set(Calendar.SECOND, 0);
        start.set(Calendar.MILLISECOND, 0);
        Calendar end = (Calendar) start.clone();
        end.add(Calendar.MONTH, 1);
        final long from = start.getTimeInMillis();
        final long to = end.getTimeInMillis();

        io.execute(() -> {
            TransactionDao dao = db.transactionDao();
            List<TransactionEntity> list = dao.getBetween(from, to);
            double income = dao.income(from, to);
            double spent = dao.spent(from, to);
            double fees = dao.fees(from, to);
            double saved = dao.movedToSavings(from, to);

            runOnUiThread(() -> {
                adapter.submit(list);
                incomeView.setText(money(income));
                spentView.setText(money(spent));
                feesView.setText(money(fees));
                savedView.setText(money(saved));
            });
        });
    }

    /** Tap a transaction to change its category. The app remembers it for that merchant. */
    private void pickCategory(TransactionEntity t) {
        new AlertDialog.Builder(this)
                .setTitle(t.party.isEmpty() ? t.code : t.party)
                .setItems(Categorizer.CATEGORIES, (dialog, which) -> {
                    String category = Categorizer.CATEGORIES[which];
                    io.execute(() -> {
                        db.transactionDao().setCategory(t.id, category);
                        if (!t.party.isEmpty()) {
                            db.ruleDao().upsert(new CategoryRule(t.party.toUpperCase(Locale.ENGLISH), category));
                            db.transactionDao().setCategoryForParty(t.party, category);
                        }
                        runOnUiThread(this::refresh);
                    });
                })
                .show();
    }

    private static String money(double v) {
        return String.format(Locale.ENGLISH, "KSh %,.2f", v);
    }
}
