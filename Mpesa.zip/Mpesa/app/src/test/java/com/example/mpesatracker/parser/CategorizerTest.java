package com.example.mpesatracker.parser;

import static org.junit.Assert.assertEquals;

import com.example.mpesatracker.data.Categorizer;

import org.junit.Test;

public class CategorizerTest {

    private static MpesaParser.Transaction tx(MpesaParser.Type type, String party) {
        MpesaParser.Transaction t = new MpesaParser.Transaction();
        t.type = type;
        t.party = party;
        return t;
    }

    @Test
    public void keywordRules() {
        assertEquals("Food & Groceries", Categorizer.categorize(tx(MpesaParser.Type.TILL, "NAIVAS SUPERMARKET"), null));
        assertEquals("Utilities", Categorizer.categorize(tx(MpesaParser.Type.PAYBILL, "KENYA POWER"), null));
        assertEquals("Savings", Categorizer.categorize(tx(MpesaParser.Type.PAYBILL, "M-SHWARI"), null));
    }

    @Test
    public void typeRulesBeatKeywords() {
        assertEquals("Income", Categorizer.categorize(tx(MpesaParser.Type.RECEIVED, "NAIVAS SUPERMARKET"), null));
        assertEquals("Cash Withdrawal", Categorizer.categorize(tx(MpesaParser.Type.WITHDRAW, "123456 - AGENT"), null));
    }

    @Test
    public void unknownPersonFallsBackToTransfers() {
        assertEquals("Transfers", Categorizer.categorize(tx(MpesaParser.Type.SENT, "JANE DOE"), null));
        assertEquals("Uncategorised", Categorizer.categorize(tx(MpesaParser.Type.TILL, "MYSTERY SHOP"), null));
    }

    @Test
    public void learnedRuleWins() {
        Categorizer.RuleSource learned = party -> party.equals("JANE DOE") ? "Rent" : null;
        assertEquals("Rent", Categorizer.categorize(tx(MpesaParser.Type.SENT, "JANE DOE"), learned));
    }
}
