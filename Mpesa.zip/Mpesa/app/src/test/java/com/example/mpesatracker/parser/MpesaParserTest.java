package com.example.mpesatracker.parser;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;

import java.util.Calendar;

/**
 * Put this in app/src/test/java/com/example/mpesatracker/parser/
 *
 * The messages below are MADE-UP samples in the layouts I know of.
 * Replace them with real ones from your phone (blur names and numbers)
 * and add one test per real layout you find.
 */
public class MpesaParserTest {

    private static final double DELTA = 0.001;

    @Test
    public void sentToPerson() {
        MpesaParser.Transaction t = MpesaParser.parse(
                "TKA1B2C3D4 Confirmed. Ksh500.00 sent to JANE DOE 0722123456 on 5/10/26 at 2:30 PM. "
                + "New M-PESA balance is Ksh1,000.00. Transaction cost, Ksh7.00. "
                + "Amount you can transact within the day is 499,500.00.");

        assertEquals("TKA1B2C3D4", t.code);
        assertEquals(MpesaParser.Type.SENT, t.type);
        assertEquals(500.00, t.amount, DELTA);
        assertEquals(7.00, t.fee, DELTA);
        assertEquals(1000.00, t.balance, DELTA);
        assertEquals("JANE DOE", t.party);
        assertEquals(507.00, t.totalCost(), DELTA);

        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(t.timestamp);
        assertEquals(2026, c.get(Calendar.YEAR));
        assertEquals(Calendar.OCTOBER, c.get(Calendar.MONTH));
        assertEquals(5, c.get(Calendar.DAY_OF_MONTH));
        assertEquals(14, c.get(Calendar.HOUR_OF_DAY));
    }

    @Test
    public void received() {
        MpesaParser.Transaction t = MpesaParser.parse(
                "TKA1B2C3D5 Confirmed. You have received Ksh2,000.00 from JOHN DOE 0712123456 "
                + "on 6/10/26 at 9:15 AM. New M-PESA balance is Ksh3,000.00.");

        assertEquals(MpesaParser.Type.RECEIVED, t.type);
        assertEquals(2000.00, t.amount, DELTA);
        assertEquals("JOHN DOE", t.party);
        assertEquals(false, t.isOutflow());
    }

    @Test
    public void paybill() {
        MpesaParser.Transaction t = MpesaParser.parse(
                "TKA1B2C3D6 Confirmed. Ksh1,200.00 sent to KENYA POWER for account 1234567 "
                + "on 7/10/26 at 6:00 PM. New M-PESA balance is Ksh1,800.00. Transaction cost, Ksh5.00.");

        assertEquals(MpesaParser.Type.PAYBILL, t.type);
        assertEquals("KENYA POWER", t.party);
        assertEquals("1234567", t.account);
        assertEquals(1200.00, t.amount, DELTA);
    }

    @Test
    public void tillPayment() {
        MpesaParser.Transaction t = MpesaParser.parse(
                "TKA1B2C3D7 Confirmed. Ksh350.00 paid to NAIVAS SUPERMARKET. on 8/10/26 at 1:05 PM. "
                + "New M-PESA balance is Ksh1,450.00. Transaction cost, Ksh0.00.");

        assertEquals(MpesaParser.Type.TILL, t.type);
        assertEquals("NAIVAS SUPERMARKET", t.party);
        assertEquals(350.00, t.amount, DELTA);
    }

    @Test
    public void withdraw() {
        MpesaParser.Transaction t = MpesaParser.parse(
                "TKA1B2C3D8 Confirmed. on 9/10/26 at 4:20 PM Withdraw Ksh1,000.00 from "
                + "123456 - MAMA PESA AGENT NAIROBI New M-PESA balance is Ksh450.00. "
                + "Transaction cost, Ksh28.00.");

        assertEquals(MpesaParser.Type.WITHDRAW, t.type);
        assertEquals(1000.00, t.amount, DELTA);
        assertEquals(28.00, t.fee, DELTA);
    }

    @Test
    public void airtime() {
        MpesaParser.Transaction t = MpesaParser.parse(
                "TKA1B2C3D9 confirmed. You bought Ksh50.00 of airtime on 10/10/26 at 8:00 AM. "
                + "New M-PESA balance is Ksh400.00. Transaction cost, Ksh0.00.");

        assertEquals(MpesaParser.Type.AIRTIME, t.type);
        assertEquals(50.00, t.amount, DELTA);
    }

    @Test
    public void nonMpesaTextIsIgnored() {
        assertNull(MpesaParser.parse("Your data bundle has been activated."));
        assertNull(MpesaParser.parse(null));
    }
}
